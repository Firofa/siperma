
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Selamat Datang <?= $user['name']; ?>, di Petunjuk Penggunaan</h1>
          <embed src="<?= base_url('assets/pdf/petunjuk_penggunaan.pdf'); ?>" width="800px" height="400px" />
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      